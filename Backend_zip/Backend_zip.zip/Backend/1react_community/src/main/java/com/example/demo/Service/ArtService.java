package com.example.demo.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.ArtRepository;
import com.example.demo.Student.Community;

@Service
public class ArtService {
	
	@Autowired
	private ArtRepository stu;

	public Community saveDetails(Community s) {
		return stu.save(s);
	}
	

	public List<Community> getAllDetails() {
		List<Community> arr = new ArrayList<>();
		arr = (List<Community>) stu.findAll();
		return arr;
	}

	public void deleteDepartmentById(int id) {
		stu.deleteById(id);
	}
	public Community update(long id,Community s) {
		
		return stu.saveAndFlush(s);
	}

	public Optional<Community> findById(int id) {
		Optional<Community> stud = stu.findById(id);
		return stud;
	}

}

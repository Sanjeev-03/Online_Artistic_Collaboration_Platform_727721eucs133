package com.springapp.RegisterLogin.Repository;

public interface community_repo {
	
}

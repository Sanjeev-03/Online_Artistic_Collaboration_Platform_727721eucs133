package com.springapp.RegisterLogin.Controller;

public class community_controller {

}

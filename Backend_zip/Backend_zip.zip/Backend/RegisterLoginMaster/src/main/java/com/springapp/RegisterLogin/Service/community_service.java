package com.springapp.RegisterLogin.Service;

public class community_service {

}

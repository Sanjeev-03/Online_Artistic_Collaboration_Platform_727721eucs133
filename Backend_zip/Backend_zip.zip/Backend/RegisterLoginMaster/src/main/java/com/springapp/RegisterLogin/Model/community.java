package com.springapp.RegisterLogin.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity

public class community {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long Artist_id;
	
	private String Artist_Name;

	private String email;
	
	private String Domain;

	public Long getArtist_id() {
		return Artist_id;
	}

	public void setArtist_id(Long artist_id) {
		Artist_id = artist_id;
	}

	public String getArtist_Name() {
		return Artist_Name;
	}

	public void setArtist_Name(String artist_Name) {
		Artist_Name = artist_Name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDomain() {
		return Domain;
	}

	public void setDomain(String domain) {
		Domain = domain;
	}

	public community(Long artist_id, String artist_Name, String email, String domain) {
		super();
		Artist_id = artist_id;
		Artist_Name = artist_Name;
		this.email = email;
		Domain = domain;
	}
	
	public community() {}
	
	
}
